# Video Remix

Aplicación Android que coge los vídeos de una carpeta, elige fragmentos al azar y los une en un único vídeo con la duración exacta que le indiques.

## Qué hace

1. Eliges una carpeta del móvil (o de la tarjeta SD / almacenamiento externo).
2. La app analiza todos los vídeos que hay dentro y calcula sus duraciones.
3. Indicas la duración total del remix (minutos y segundos).
4. Indicas cuánto debe durar cada corte (un rango, por ejemplo entre 2 y 5 segundos).
5. Al pulsar **Crear remix**, la app:
   - baraja los vídeos y los va usando por turnos, sin repetir el mismo dos veces seguidas;
   - de cada uno extrae un fragmento de duración aleatoria empezando en un punto aleatorio;
   - sigue añadiendo cortes hasta llegar a la duración pedida (el último se recorta para que cuadre al segundo);
   - escala todo a la misma resolución y lo exporta a un solo MP4 (H.264 / AAC).
6. El resultado se guarda en **Películas/VideoRemix** y se puede reproducir o compartir desde la propia app.

Cada vez que pulsas el botón el resultado es distinto, aunque no cambies ningún ajuste.

## Ajustes disponibles

| Ajuste | Descripción |
|---|---|
| Carpeta | Se elige con el selector del sistema; el permiso queda guardado entre sesiones |
| Incluir subcarpetas | Busca vídeos también dentro de las carpetas anidadas |
| Duración | Minutos y segundos del remix final |
| Duración de los cortes | Rango mínimo/máximo, de 1 a 20 segundos |
| Resolución | 480p, 720p o 1080p |
| Audio | Conservar o eliminar el sonido original |

## Cómo compilarlo

1. Abre Android Studio (Ladybug o posterior) → **Open** → selecciona la carpeta `VideoRemix`.
2. Android Studio descargará Gradle y las dependencias automáticamente. Si pide generar el Gradle Wrapper, acepta.
3. Conecta el móvil con la depuración USB activada y pulsa **Run**.

Para generar el APK a mano:

```bash
./gradlew assembleDebug
# el archivo queda en app/build/outputs/apk/debug/app-debug.apk
```

Requisitos: JDK 17, Android SDK 34, Android 8.0 (API 26) o superior en el móvil.

## Detalles técnicos

- **Kotlin + Jetpack Compose (Material 3)** para la interfaz.
- **Media3 Transformer 1.4.1** para cortar y concatenar. Se usa `Composition` con una `EditedMediaItemSequence`; cada corte lleva su `ClippingConfiguration` y un efecto `Presentation` que lo escala a la resolución de salida, lo que permite mezclar vídeos verticales y horizontales sin que falle la exportación.
- `experimentalSetForceAudioTrack` genera silencio en los clips que no tengan pista de audio, para que la mezcla no se rompa.
- **Storage Access Framework** (`OPEN_DOCUMENT_TREE`) para leer la carpeta: no hace falta el permiso de almacenamiento en Android 10+.
- **MediaStore** para guardar el resultado en la galería.

### Estructura del código

| Archivo | Responsabilidad |
|---|---|
| `VideoScanner.kt` | Recorre la carpeta y lee la duración de cada vídeo |
| `ClipPlanner.kt` | Decide qué fragmento de qué vídeo y en qué orden (toda la aleatoriedad vive aquí) |
| `RemixEngine.kt` | Exporta con Media3 Transformer y reporta el progreso |
| `MediaSaver.kt` | Guarda en la galería y prepara los intents de abrir/compartir |
| `RemixViewModel.kt` | Estado de la pantalla |
| `MainActivity.kt` | Interfaz en Compose |

## Limitaciones que conviene conocer

- La exportación ocurre mientras la app está en primer plano (la pantalla se mantiene encendida). Si necesitas que siga con la app en segundo plano, hay que mover `RemixEngine` a un *foreground service*.
- La velocidad depende del codificador del móvil: un remix de 1 minuto suele tardar entre 20 y 60 segundos.
- Vídeos con códecs poco comunes (algunos AVI o MKV antiguos) pueden ser rechazados por el decodificador del dispositivo; se ignoran al escanear si no se puede leer su duración.
- Si mezclas material con relaciones de aspecto muy distintas, `LAYOUT_SCALE_TO_FIT` añade bandas negras. Si prefieres recortar en lugar de encajar, cambia el efecto por `Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP` en `RemixEngine.kt`.

## Ideas para ampliarlo

- Música de fondo: añadir una segunda `EditedMediaItemSequence` con un audio y silenciar el original.
- Transiciones o fundidos entre cortes.
- Semilla fija para poder reproducir el mismo remix (`ClipPlanner.plan` ya acepta un parámetro `seed`).
- Sincronizar los cortes con el BPM de una canción.
