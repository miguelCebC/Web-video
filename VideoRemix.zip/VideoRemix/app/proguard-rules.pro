# Reglas por defecto
