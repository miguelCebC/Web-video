package com.example.videoremix

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/** Un vídeo encontrado en la carpeta que eligió el usuario. */
data class VideoItem(
    val uri: Uri,
    val name: String,
    val durationMs: Long
)

/**
 * Recorre la carpeta seleccionada mediante el Storage Access Framework y devuelve
 * todos los vídeos utilizables (con duración conocida y mayor que medio segundo).
 */
object VideoScanner {

    private val VIDEO_EXTENSIONS = setOf(
        "mp4", "m4v", "mov", "3gp", "mkv", "webm", "avi", "ts", "mts", "mpg", "mpeg"
    )

    fun scan(context: Context, treeUri: Uri, recursive: Boolean): List<VideoItem> {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
        val found = mutableListOf<DocumentFile>()
        collect(root, recursive, found, depth = 0)

        return found.mapNotNull { doc ->
            val duration = readDurationMs(context, doc.uri)
            if (duration > 500L) {
                VideoItem(doc.uri, doc.name ?: "video", duration)
            } else {
                null // archivo corrupto, no soportado o demasiado corto
            }
        }
    }

    private fun collect(
        dir: DocumentFile,
        recursive: Boolean,
        out: MutableList<DocumentFile>,
        depth: Int
    ) {
        if (depth > 8) return // evita recursiones absurdas
        for (file in dir.listFiles()) {
            if (file.isDirectory) {
                if (recursive) collect(file, true, out, depth + 1)
            } else if (isVideo(file)) {
                out.add(file)
            }
        }
    }

    private fun isVideo(file: DocumentFile): Boolean {
        file.type?.let { if (it.startsWith("video/")) return true }
        val name = file.name ?: return false
        return name.substringAfterLast('.', "").lowercase() in VIDEO_EXTENSIONS
    }

    private fun readDurationMs(context: Context, uri: Uri): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }
}
