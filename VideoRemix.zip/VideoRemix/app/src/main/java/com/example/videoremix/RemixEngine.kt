package com.example.videoremix

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Une los cortes en un único MP4 usando Media3 Transformer.
 *
 * Todos los cortes se escalan a la misma resolución de salida (con Presentation),
 * lo que permite mezclar vídeos verticales y horizontales de distintas fuentes.
 * Debe llamarse desde el hilo principal.
 */
@androidx.annotation.OptIn(markerClass = [UnstableApi::class])
class RemixEngine(private val context: Context) {

    interface Callback {
        fun onProgress(percent: Int)
        fun onSuccess(file: File)
        fun onError(message: String)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val progressHolder = ProgressHolder()
    private var transformer: Transformer? = null
    private var callback: Callback? = null

    private val progressPoller = object : Runnable {
        override fun run() {
            val current = transformer ?: return
            if (current.getProgress(progressHolder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                callback?.onProgress(progressHolder.progress)
            }
            handler.postDelayed(this, 400L)
        }
    }

    fun start(
        clips: List<Clip>,
        outputWidth: Int,
        outputHeight: Int,
        keepAudio: Boolean,
        callback: Callback
    ) {
        if (clips.isEmpty()) {
            callback.onError("No hay cortes que exportar.")
            return
        }
        this.callback = callback

        val presentation = Presentation.createForWidthAndHeight(
            outputWidth,
            outputHeight,
            Presentation.LAYOUT_SCALE_TO_FIT
        )

        val editedItems = clips.map { clip ->
            val mediaItem = MediaItem.Builder()
                .setUri(clip.uri)
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(clip.startMs)
                        .setEndPositionMs(clip.endMs)
                        .build()
                )
                .build()

            EditedMediaItem.Builder(mediaItem)
                .setRemoveAudio(!keepAudio)
                .setEffects(Effects(emptyList(), listOf(presentation)))
                .build()
        }

        val composition = Composition.Builder(listOf(EditedMediaItemSequence(editedItems)))
            // Genera silencio en los clips que no tengan pista de audio, para que
            // la concatenación no falle al mezclar vídeos con y sin sonido.
            .experimentalSetForceAudioTrack(keepAudio)
            .build()

        val outputFile = File(context.cacheDir, "remix_${System.currentTimeMillis()}.mp4")

        val newTransformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopPolling()
                    this@RemixEngine.callback?.onProgress(100)
                    this@RemixEngine.callback?.onSuccess(outputFile)
                    transformer = null
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopPolling()
                    this@RemixEngine.callback?.onError(
                        exportException.message ?: "Error desconocido durante la exportación."
                    )
                    transformer = null
                }
            })
            .build()

        transformer = newTransformer

        try {
            newTransformer.start(composition, outputFile.absolutePath)
            handler.post(progressPoller)
        } catch (e: Exception) {
            stopPolling()
            transformer = null
            callback.onError(e.message ?: "No se pudo iniciar la exportación.")
        }
    }

    fun cancel() {
        stopPolling()
        try {
            transformer?.cancel()
        } catch (_: Exception) {
        }
        transformer = null
        callback = null
    }

    private fun stopPolling() {
        handler.removeCallbacks(progressPoller)
    }
}
