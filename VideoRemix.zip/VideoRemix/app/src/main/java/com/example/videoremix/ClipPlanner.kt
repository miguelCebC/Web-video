package com.example.videoremix

import android.net.Uri
import kotlin.random.Random

/** Un fragmento concreto de un vídeo: [startMs, endMs). */
data class Clip(
    val uri: Uri,
    val name: String,
    val startMs: Long,
    val endMs: Long
) {
    val durationMs: Long get() = endMs - startMs
}

/**
 * Construye la lista de cortes del remix.
 *
 * Estrategia:
 *  - Baraja los vídeos y los va consumiendo; cuando se acaban, vuelve a barajar.
 *  - De cada vídeo toma un trozo de duración aleatoria dentro del rango pedido
 *    y empezando en un punto aleatorio.
 *  - Evita repetir el mismo vídeo dos veces seguidas si hay alternativa.
 *  - El último corte se recorta para que el total coincida exactamente con la
 *    duración objetivo.
 */
object ClipPlanner {

    private const val MIN_USEFUL_MS = 400L

    fun plan(
        videos: List<VideoItem>,
        targetMs: Long,
        minClipMs: Long,
        maxClipMs: Long,
        seed: Long? = null
    ): List<Clip> {
        if (videos.isEmpty() || targetMs <= 0L) return emptyList()

        val random = if (seed != null) Random(seed) else Random(System.nanoTime())
        val lowerBound = minClipMs.coerceAtLeast(MIN_USEFUL_MS)
        val upperBound = maxClipMs.coerceAtLeast(lowerBound)

        val clips = mutableListOf<Clip>()
        var total = 0L
        var pool = videos.shuffled(random).toMutableList()
        var previousUri: Uri? = null
        var guard = 0

        while (total < targetMs && guard < 20_000) {
            guard++

            val remaining = targetMs - total
            if (remaining < MIN_USEFUL_MS) break

            if (pool.isEmpty()) pool = videos.shuffled(random).toMutableList()

            // No repetir el vídeo anterior si hay otra opción disponible.
            var index = 0
            if (pool.size > 1 && pool[0].uri == previousUri) index = 1
            val video = pool.removeAt(index)
            previousUri = video.uri

            var length = if (upperBound > lowerBound) {
                random.nextLong(lowerBound, upperBound + 1)
            } else {
                lowerBound
            }
            length = minOf(length, video.durationMs, remaining)
            if (length < MIN_USEFUL_MS) {
                // El vídeo es más corto que el mínimo: úsalo entero si aporta algo.
                length = minOf(video.durationMs, remaining)
                if (length < MIN_USEFUL_MS) continue
            }

            val maxStart = video.durationMs - length
            val start = if (maxStart > 0L) random.nextLong(0L, maxStart + 1) else 0L

            clips.add(Clip(video.uri, video.name, start, start + length))
            total += length
        }

        return clips
    }

    fun totalDurationMs(clips: List<Clip>): Long = clips.sumOf { it.durationMs }
}
