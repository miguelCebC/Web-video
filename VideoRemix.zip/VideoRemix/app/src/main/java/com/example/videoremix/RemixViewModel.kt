package com.example.videoremix

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class OutputQuality(val label: String, val width: Int, val height: Int) {
    SD("480p", 854, 480),
    HD("720p", 1280, 720),
    FULL_HD("1080p", 1920, 1080)
}

class RemixViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("video_remix", Context.MODE_PRIVATE)
    private val engine = RemixEngine(app)

    // --- Carpeta de origen ---
    var folderUri by mutableStateOf<Uri?>(null)
        private set
    var folderName by mutableStateOf<String?>(null)
        private set
    var videos by mutableStateOf<List<VideoItem>>(emptyList())
        private set
    var scanning by mutableStateOf(false)
        private set

    // --- Ajustes ---
    var minutesText by mutableStateOf("1")
    var secondsText by mutableStateOf("0")
    var minClipSeconds by mutableStateOf(2f)
    var maxClipSeconds by mutableStateOf(5f)
    var quality by mutableStateOf(OutputQuality.HD)
    var keepAudio by mutableStateOf(true)
    var includeSubfolders by mutableStateOf(true)

    // --- Exportación ---
    var exporting by mutableStateOf(false)
        private set
    var progress by mutableStateOf(0)
        private set
    var statusMessage by mutableStateOf<String?>(null)
        private set
    var errorMessage by mutableStateOf<String?>(null)
        private set
    var resultFile by mutableStateOf<File?>(null)
        private set
    var resultUri by mutableStateOf<Uri?>(null)
        private set
    var lastClipCount by mutableStateOf(0)
        private set

    init {
        prefs.getString("folder_uri", null)?.let { saved ->
            val uri = Uri.parse(saved)
            val stillGranted = getApplication<Application>().contentResolver
                .persistedUriPermissions
                .any { it.uri == uri && it.isReadPermission }
            if (stillGranted) setFolder(uri)
        }
    }

    val targetMs: Long
        get() {
            val minutes = minutesText.toLongOrNull() ?: 0L
            val seconds = secondsText.toLongOrNull() ?: 0L
            return (minutes * 60L + seconds) * 1000L
        }

    val totalAvailableMs: Long
        get() = videos.sumOf { it.durationMs }

    val canGenerate: Boolean
        get() = !exporting && !scanning && videos.isNotEmpty() && targetMs >= 1000L

    fun setFolder(uri: Uri) {
        val context = getApplication<Application>()
        try {
            context.contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Puede fallar al restaurar una carpeta antigua; el escaneo lo detectará.
        }
        prefs.edit().putString("folder_uri", uri.toString()).apply()
        folderUri = uri
        folderName = DocumentFile.fromTreeUri(context, uri)?.name ?: uri.lastPathSegment
        rescan()
    }

    fun rescan() {
        val uri = folderUri ?: return
        scanning = true
        errorMessage = null
        viewModelScope.launch {
            val found = withContext(Dispatchers.IO) {
                VideoScanner.scan(getApplication(), uri, includeSubfolders)
            }
            videos = found
            scanning = false
            if (found.isEmpty()) {
                errorMessage = "No se encontraron vídeos legibles en esa carpeta."
            }
        }
    }

    fun generate() {
        if (!canGenerate) return

        val minMs = (minClipSeconds * 1000f).toLong()
        val maxMs = (maxClipSeconds * 1000f).toLong().coerceAtLeast(minMs)

        val clips = ClipPlanner.plan(
            videos = videos,
            targetMs = targetMs,
            minClipMs = minMs,
            maxClipMs = maxMs
        )

        if (clips.isEmpty()) {
            errorMessage = "No se pudo planificar el remix con esos ajustes."
            return
        }

        errorMessage = null
        resultFile = null
        resultUri = null
        progress = 0
        exporting = true
        lastClipCount = clips.size
        statusMessage = "Uniendo ${clips.size} cortes…"

        engine.start(
            clips = clips,
            outputWidth = quality.width,
            outputHeight = quality.height,
            keepAudio = keepAudio,
            callback = object : RemixEngine.Callback {
                override fun onProgress(percent: Int) {
                    progress = percent
                }

                override fun onSuccess(file: File) {
                    exporting = false
                    progress = 100
                    resultFile = file
                    val name = "remix_" + SimpleDateFormat(
                        "yyyyMMdd_HHmmss",
                        Locale.US
                    ).format(Date()) + ".mp4"
                    val saved = MediaSaver.saveToGallery(getApplication(), file, name)
                    resultUri = saved ?: MediaSaver.uriFor(getApplication(), file)
                    statusMessage = if (saved != null) {
                        "Guardado en Películas/VideoRemix"
                    } else {
                        "Remix listo (guardado en el almacenamiento de la app)"
                    }
                }

                override fun onError(message: String) {
                    exporting = false
                    statusMessage = null
                    errorMessage = message
                }
            }
        )
    }

    fun cancel() {
        engine.cancel()
        exporting = false
        progress = 0
        statusMessage = null
    }

    fun dismissError() {
        errorMessage = null
    }

    override fun onCleared() {
        engine.cancel()
        super.onCleared()
    }
}
