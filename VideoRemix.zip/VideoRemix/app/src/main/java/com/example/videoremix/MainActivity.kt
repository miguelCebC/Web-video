package com.example.videoremix

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // La exportación se detiene si la pantalla se apaga, así que la mantenemos encendida.
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    RemixScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RemixScreen(vm: RemixViewModel = viewModel()) {
    val context = androidx.compose.ui.platform.LocalContext.current

    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) vm.setFolder(uri)
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Video Remix") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(horizontal = 16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(Modifier.height(4.dp))

            // ---------- 1. Carpeta ----------
            SectionCard(title = "1 · Carpeta de vídeos") {
                Button(
                    onClick = { folderPicker.launch(null) },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !vm.exporting
                ) {
                    Text(if (vm.folderUri == null) "Elegir carpeta" else "Cambiar carpeta")
                }

                vm.folderName?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, fontWeight = FontWeight.Medium)
                }

                Spacer(Modifier.height(6.dp))
                when {
                    vm.scanning -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.height(18.dp).width(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Analizando vídeos…", style = MaterialTheme.typography.bodySmall)
                    }

                    vm.videos.isNotEmpty() -> Text(
                        "${vm.videos.size} vídeos · ${formatDuration(vm.totalAvailableMs)} disponibles",
                        style = MaterialTheme.typography.bodySmall
                    )

                    vm.folderUri != null -> Text(
                        "Sin vídeos utilizables.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(Modifier.height(4.dp))
                SwitchRow(
                    label = "Incluir subcarpetas",
                    checked = vm.includeSubfolders,
                    enabled = !vm.exporting
                ) {
                    vm.includeSubfolders = it
                    vm.rescan()
                }
            }

            // ---------- 2. Duración ----------
            SectionCard(title = "2 · Duración del remix") {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = vm.minutesText,
                        onValueChange = { vm.minutesText = it.filter { c -> c.isDigit() }.take(3) },
                        label = { Text("Minutos") },
                        singleLine = true,
                        enabled = !vm.exporting,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = vm.secondsText,
                        onValueChange = { vm.secondsText = it.filter { c -> c.isDigit() }.take(2) },
                        label = { Text("Segundos") },
                        singleLine = true,
                        enabled = !vm.exporting,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Total: ${formatDuration(vm.targetMs)}",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // ---------- 3. Cortes ----------
            SectionCard(title = "3 · Duración de cada corte") {
                Text(
                    "Entre ${vm.minClipSeconds.roundToInt()} s y ${vm.maxClipSeconds.roundToInt()} s",
                    style = MaterialTheme.typography.bodyMedium
                )
                RangeSlider(
                    value = vm.minClipSeconds..vm.maxClipSeconds,
                    onValueChange = { range ->
                        vm.minClipSeconds = range.start
                        vm.maxClipSeconds = range.endInclusive
                    },
                    valueRange = 1f..20f,
                    steps = 18,
                    enabled = !vm.exporting
                )
                Text(
                    "Cortes cortos = remix más movido. El punto de inicio dentro de cada vídeo también es aleatorio.",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            // ---------- 4. Salida ----------
            SectionCard(title = "4 · Salida") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutputQuality.entries.forEach { q ->
                        FilterChip(
                            selected = vm.quality == q,
                            onClick = { vm.quality = q },
                            enabled = !vm.exporting,
                            label = { Text(q.label) }
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                SwitchRow(
                    label = "Conservar el audio original",
                    checked = vm.keepAudio,
                    enabled = !vm.exporting
                ) { vm.keepAudio = it }
            }

            // ---------- Acción ----------
            Button(
                onClick = { vm.generate() },
                enabled = vm.canGenerate,
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("Crear remix")
            }

            if (vm.exporting) {
                SectionCard(title = "Procesando") {
                    LinearProgressIndicator(
                        progress = { vm.progress / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("${vm.progress}% · ${vm.lastClipCount} cortes")
                    vm.statusMessage?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { vm.cancel() }) { Text("Cancelar") }
                }
            }

            val result = vm.resultUri
            if (!vm.exporting && result != null) {
                SectionCard(title = "¡Remix listo!") {
                    vm.statusMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            runCatching {
                                context.startActivity(MediaSaver.viewIntent(context, result))
                            }.onFailure {
                                Toast.makeText(context, "No hay reproductor disponible", Toast.LENGTH_SHORT).show()
                            }
                        }) { Text("Reproducir") }

                        OutlinedButton(onClick = {
                            context.startActivity(
                                Intent.createChooser(MediaSaver.shareIntent(result), "Compartir remix")
                            )
                        }) { Text("Compartir") }
                    }
                }
            }

            vm.errorMessage?.let { message ->
                SectionCard(title = "Error") {
                    Text(message, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { vm.dismissError() }) { Text("Cerrar") }
                }
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SwitchRow(
    label: String,
    checked: Boolean,
    enabled: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange, enabled = enabled)
    }
}

private fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.US, "%d:%02d", minutes, seconds)
}
